/* Init Tooltips */
$(document).ready(function(){
  if ( $( ".hero-slider" ).length ) {
    $(".hero-slider").slick({
      asNavFor: '.hero-slider-nav',
      autoplay: false,
      infinite: true,
      speed: 500,
      arrows:true,
      focusOnSelect: true,
      swipe:true,
      pauseOnHover:true,
      pauseOnFocus:true,
      dots:false
    });
  }
  if ( $( ".hero-slider-nav" ).length ) {
    $('.hero-slider-nav').slick({
      asNavFor: '.hero-slider',
      infinite: true,
      slidesToShow: 1,
      dots: true,
        centerMode: false,
        focusOnSelect: true
    });
  }
});
